-- Enable pgvector extension for handling vector embeddings
create extension if not exists vector;

-- Table for storing parsed invoices/receipts
create table if not exists invoices (
    id uuid primary key default gen_random_uuid(),
    filename text not null,
    raw_text text,
    fields jsonb,
    line_items jsonb,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Table for storing text chunks and their vector embeddings
create table if not exists invoice_chunks (
    id uuid primary key default gen_random_uuid(),
    invoice_id uuid references invoices(id) on delete cascade,
    chunk_type text check (chunk_type in ('field', 'line_item')),
    content text not null,
    metadata jsonb, -- Stores page number, bounding box polygons, field name, etc.
    embedding vector(768) -- Google text-embedding-004 produces 768-dimensional vectors
);

-- Table for bank statements to perform financial reconciliation
create table if not exists bank_statements (
    id uuid primary key default gen_random_uuid(),
    transaction_date date not null,
    description text not null,
    amount numeric(12, 2) not null,
    reference_code text
);

-- RPC Function for Cosine Similarity Vector Search
create or replace function match_invoice_chunks (
    query_embedding vector(768),
    match_threshold float,
    match_count int,
    filter_invoice_id uuid default null
)
returns table (
    id uuid,
    invoice_id uuid,
    chunk_type text,
    content text,
    metadata jsonb,
    similarity float
)
language sql stable
as $$
    select
        invoice_chunks.id,
        invoice_chunks.invoice_id,
        invoice_chunks.chunk_type,
        invoice_chunks.content,
        invoice_chunks.metadata,
        1 - (invoice_chunks.embedding <=> query_embedding) as similarity
    from invoice_chunks
    where (filter_invoice_id is null or invoice_chunks.invoice_id = filter_invoice_id)
      and 1 - (invoice_chunks.embedding <=> query_embedding) > match_threshold
    order by invoice_chunks.embedding <=> query_embedding
    limit match_count;
$$;
