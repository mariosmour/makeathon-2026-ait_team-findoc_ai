import os
from io import BytesIO
from typing import Any, Dict, List

def analyze_invoice(file_bytes: bytes, filename: str) -> Dict[str, Any]:
    # HACKATHON EMERGENCY MOCK - ΠΑΡΑΚΑΜΨΗ AZURE
    return {
        "filename": filename,
        "raw_text": "Τιμολόγιο Παροχής Υπηρεσιών\nΠρομηθευτής: TechCorp Solutions Ltd\nΑΦΜ: 094123456\nΗμερομηνία: 12/03/2026\n\nΓραμμές Τιμολογίου:\n1. Cloud Hosting - €800,00\n2. API Calls - €350,00\n3. Support License - €300,00\n\nΣυνολικό Ποσό: €1.450,00",
        "fields": {
            "VendorName": {"value": "TechCorp Solutions Ltd", "content": "TechCorp Solutions Ltd", "confidence": 0.99, "page": 1, "polygon": [100, 100, 250, 100, 250, 140, 100, 140]},
            "VendorTaxId": {"value": "094123456", "content": "094123456", "confidence": 0.98, "page": 1, "polygon": [100, 150, 200, 150, 200, 170, 100, 170]},
            "InvoiceDate": {"value": "12/03/2026", "content": "12/03/2026", "confidence": 0.97, "page": 1, "polygon": [450, 150, 570, 150, 570, 180, 450, 180]},
            "InvoiceTotal": {"value": "1450.00 EUR", "content": "€1.450,00", "confidence": 0.99, "page": 1, "polygon": [500, 800, 600, 800, 600, 830, 500, 830]}
        },
        "line_items": [
            {"Description": {"value": "Cloud Hosting", "content": "Cloud Hosting", "page": 1, "polygon": [50, 300, 200, 300, 200, 320, 50, 320]}, "Amount": {"value": "800.00", "content": "€800,00", "page": 1, "polygon": [500, 300, 560, 300, 560, 320, 500, 320]}},
            {"Description": {"value": "API Calls", "content": "API Calls", "page": 1, "polygon": [50, 330, 150, 330, 150, 350, 50, 350]}, "Amount": {"value": "350.00", "content": "€350,00", "page": 1, "polygon": [500, 330, 560, 330, 560, 350, 500, 350]}},
            {"Description": {"value": "Support License", "content": "Support License", "page": 1, "polygon": [50, 360, 180, 360, 180, 380, 50, 380]}, "Amount": {"value": "300.00", "content": "€300,00", "page": 1, "polygon": [500, 360, 560, 360, 560, 380, 500, 380]}}
        ],
        "raw": {}
    }