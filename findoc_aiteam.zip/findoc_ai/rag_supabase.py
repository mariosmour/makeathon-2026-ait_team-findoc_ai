import os
from typing import Any, Dict, List
from supabase import create_client, Client
from google import genai

def get_supabase_client() -> Client:
    # 1. ΒΑΛΕ ΤΟ PROJECT URL ΑΠΟ ΤΟ SUPABASE (πρέπει να ξεκινάει από https://)
    url = "https://wctoxhxxogtydqzfadqb.supabase.co" 
    
    # 2. ΒΑΛΕ ΤΟ ANON PUBLIC KEY ΑΠΟ ΤΟ SUPABASE (ξεκινάει από eyJ...)
    key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndjdG94aHh4b2d0eWRxemZhZHFiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg5NDE1MzQsImV4cCI6MjA5NDUxNzUzNH0.l3kr_9IGaBcTyYjwpA1gqEh7kg-1fU684wCOM1yQ_8M"
    
    if not url or not key:
        raise RuntimeError("Missing Supabase URL or Key.")
    return create_client(url, key)

def get_gemini_client() -> genai.Client:
    # 3. ΒΑΛΕ ΤΟ GOOGLE GEMINI API KEY ΣΟΥ ΕΔΩ
    api_key = "AIzaSyAMuM8LS-dRQImp_Rp2UfLu2l6ieXLqaP0"
    
    if not api_key:
        raise RuntimeError("Missing GEMINI_API_KEY.")
    return genai.Client(api_key=api_key)

def generate_vector(text: str) -> List[float]:
    # HACKATHON BYPASS: Στέλνουμε ένα σταθερό vector για να μην κρασάρει η Google!
    # Το Supabase (pgvector) θα το δεχτεί κανονικότατα και η βάση θα γεμίσει!
    return [0.01] * 768

def build_chunks(analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
    chunks = []
    filename = analysis["filename"]

    for field_name, data in analysis.get("fields", {}).items():
        value = data.get("value")
        content = data.get("content")
        if value is None and not content:
            continue

        text_representation = (
            f"Document: {filename}\n"
            f"Field: {field_name}\n"
            f"Value: {value}\n"
            f"Source text: {content}\n"
        )
        chunks.append({
            "chunk_type": "field",
            "content": text_representation,
            "metadata": {
                "field_name": field_name,
                "value": value,
                "source_text": content,
                "page": data.get("page"),
                "polygon": data.get("polygon"),
                "confidence": data.get("confidence"),
                "filename": filename
            }
        })

    for idx, item in enumerate(analysis.get("line_items", []), start=1):
        parts = []
        source_parts = []
        for key, data in item.items():
            parts.append(f"{key}: {data.get('value')}")
            if data.get("content"):
                source_parts.append(data.get("content"))

        text_representation = (
            f"Document: {filename}\n"
            f"Line item #{idx}\n"
            + "\n".join(parts) + "\n"
            f"Source text: {' | '.join(source_parts)}"
        )
        first_field = next(iter(item.values()), {})
        chunks.append({
            "chunk_type": "line_item",
            "content": text_representation,
            "metadata": {
                "line_item_index": idx,
                "value": parts,
                "source_text": " | ".join(source_parts),
                "page": first_field.get("page"),
                "polygon": first_field.get("polygon"),
                "confidence": first_field.get("confidence"),
                "filename": filename
            }
        })
    return chunks

def store_document_in_supabase(analysis: Dict[str, Any]) -> str:
    supabase = get_supabase_client()
    doc_res = supabase.table("invoices").insert({
        "filename": analysis["filename"],
        "raw_text": analysis["raw_text"],
        "fields": analysis["fields"],
        "line_items": analysis["line_items"]
    }).execute()
    
    invoice_id = doc_res.data[0]["id"]
    chunks = build_chunks(analysis)
    
    for chunk in chunks:
        vector = generate_vector(chunk["content"])
        supabase.table("invoice_chunks").insert({
            "invoice_id": invoice_id,
            "chunk_type": chunk["chunk_type"],
            "content": chunk["content"],
            "metadata": chunk["metadata"],
            "embedding": vector
        }).execute()
        
    return invoice_id

def search_supabase_chunks(invoice_id: str, question: str, top_k: int = 5) -> List[Dict[str, Any]]:
    supabase = get_supabase_client()
    query_vector = generate_vector(question)
    
    # Λέμε στο Supabase να επιστρέψει ΤΑ ΠΑΝΤΑ (match_threshold: -1.0) 
    # για να τα δώσουμε όλα στον LLM Agent και να βρει αυτός την τέλεια απάντηση!
    rpc_res = supabase.rpc("match_invoice_chunks", {
        "query_embedding": query_vector,
        "match_threshold": -1.0, 
        "match_count": 50,
        "filter_invoice_id": invoice_id
    }).execute()
    return rpc_res.data

def fetch_all_chunks_for_doc(invoice_id: str) -> List[Dict[str, Any]]:
    supabase = get_supabase_client()
    res = supabase.table("invoice_chunks").select("content, metadata").eq("invoice_id", invoice_id).execute()
    return res.data