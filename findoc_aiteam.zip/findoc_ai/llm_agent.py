import os
from typing import Any, Dict, List
import json
from google import genai

SYSTEM_PROMPT = """
Είσαι ένας εξειδικευμένος AI Agent για ερωτήσεις πάνω σε οικονομικά έγγραφα (τιμολόγια και αποδείξεις) του διαγωνισμού INFORM Makeathon 2026.

ΚΑΝΟΝΕΣ ΛΕΙΤΟΥΡΓΙΑΣ:
1. Απαντάς ΑΥΣΤΗΡΑ ΚΑΙ ΜΟΝΟ με βάση το CONTEXT που σου παρέχεται.
2. Δεν χρησιμοποιείς καμία εξωτερική γνώση ή υποθέσεις.
3. Αν η απάντηση δεν προκύπτει ξεκάθαρα, απαντάς επακριβώς: "Δεν βρέθηκε στο έγγραφο."
4. **ΠΟΛΥ ΣΗΜΑΝΤΙΚΟ**: Κάθε φορά που δίνεις μια απάντηση, ΠΡΕΠΕΙ στο τέλος, σε μια νέα γραμμή, να εμφανίζεις τις συντεταγμένες (polygon) του εγγράφου από το οποίο βρήκες την πληροφορία, χρησιμοποιώντας ΑΚΡΙΒΩΣ αυτή τη μορφή:
   `|||CROP|||[συντεταγμένες]`

Παράδειγμα του πώς ΠΡΕΠΕΙ να απαντάς:
Το συνολικό ποσό του τιμολογίου είναι 1.450,00€.
|||CROP|||[500, 800, 600, 800, 600, 830, 500, 830]
"""

def build_context_string(chunks: List[Dict[str, Any]]) -> str:
    parts = []
    for i, chunk in enumerate(chunks, start=1):
        meta = chunk.get("metadata", chunk)
        
        # Εξασφαλίζουμε ότι οι συντεταγμένες είναι διαθέσιμες στο context
        polygon_coords = meta.get("polygon")
        
        parts.append(
            f"[CHUNK {i}]\n"
            f"Content Text:\n{chunk.get('content', chunk.get('text'))}\n"
            f"File: {meta.get('filename')}\n"
            f"Page: {meta.get('page')}\n"
            f"Polygon Coords: {json.dumps(polygon_coords)}\n" # <-- Προστέθηκε αυτό
        )
    return "\n---\n".join(parts)

def answer_with_memory(question: str, context_chunks: List[Dict[str, Any]], chat_history: List[Dict[str, str]]) -> str:
    # ΒΑΛΕ ΤΟ ΔΙΚΟ ΣΟΥ ΚΛΕΙΔΙ ΑΠΟ ΤΟ GEMINI ΕΔΩ
    api_key = "AIzaSyAMuM8LS-dRQImp_Rp2UfLu2l6ieXLqaP0"
    model = "gemini-2.5-flash"
    
    if not api_key:
        raise RuntimeError("Missing GEMINI_API_KEY.")

    client = genai.Client(api_key=api_key)
    context_str = build_context_string(context_chunks)

    formatted_prompt = f"{SYSTEM_PROMPT}\n\nCONTEXT DATA:\n{context_str}\n\nΝΕΑ ΕΡΩΤΗΣΗ: {question}"

    response = client.models.generate_content(
        model=model,
        contents=formatted_prompt
    )
    return response.text or "Δεν βρέθηκε στο έγγραφο."